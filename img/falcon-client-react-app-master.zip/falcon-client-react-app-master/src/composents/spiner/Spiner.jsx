import React from 'react'; 


const Spiner = () => {
    return (  
      <>

<div className="d-flex min-vh-100  w-100 align-items-center  justify-content-center flex-wrap">

<div className="spinner-border text-primary" role="status">
  <span className="sr-only"> </span>
</div>

</div>
</>
    );
};



export default Spiner